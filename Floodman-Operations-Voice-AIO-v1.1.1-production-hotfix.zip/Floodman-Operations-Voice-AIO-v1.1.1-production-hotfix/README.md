# Floodman Operations Voice AIO

> **Never Miss A Call Again With Floodman’s 24/7 AI Receptionist**

Floodman Operations Voice AIO is a self-hosted inbound and outbound phone-operations system built around Asterisk and AVA. It answers Floodman customer calls, handles Google-forwarded calls without talking to the announcement, collects structured job information, schedules inspections, transfers emergencies, follows up on estimates and invoices, and keeps a local operational record when Roomflow or another service is unavailable.

Version **1.1.0** adds a first-class Twilio Elastic SIP Trunking deployment path, guarded one-time trunk provisioning, controlled two-way test calls, runtime diagnostics, HTTPS deployment, safer secret handling, live-safe backups, and a stricter production preflight.

## Production status

This release is **production-hardened and ready for controlled deployment and live carrier testing**. It has passed the bundled automated tests and static validation. It is not labeled live-proven until it has completed real calls through Floodman’s public IP, Twilio number, firewall, transfer destinations, Google forwarding path, Roomflow endpoints, and chosen AVA voice provider.

Keep these disabled until the inbound test matrix passes:

```dotenv
OUTBOUND_ENABLED=false
ROOMFLOW_ENABLED=false
```

## Included

- Embedded Asterisk with generated PJSIP, RTP, ARI, AMI, transfer, failover, and test-call configuration
- AVA pinned to commit `18d4e769335f3b643aca80e084c7e66f0969491e`
- Deterministic AVA compatibility patch for JSON-safe HTTP tool bodies
- Twilio Elastic SIP Trunking runtime profile with digest credentials and IP-based inbound identification
- One-time Twilio provisioning utility with `show-config`, `plan`, `apply`, and `verify`
- Guard against silently moving an existing Twilio number away from a webhook, application, or another trunk
- UDP/RTP test profile and an optional TLS plus SDES-SRTP profile
- Controlled operator echo calls restricted by an E.164 allowlist
- Google-aware pre-greeting AudioSocket call gate
- Seven purpose-specific Floodman agents
- Emergency water intake and human escalation
- Local customer, property, lead, appointment, invoice, callback, consent, upload, campaign, and call ledger
- Configurable Roomflow synchronization with a durable retry outbox
- Customer verification and cross-customer billing isolation
- Consent evidence, partial revocation, suppression, quiet hours, frequency caps, DNC attestations, and reassignment attestations
- Public `livez`, `health`, and `readyz` probes plus authenticated detailed diagnostics
- Responsive dashboard, Docker Compose, optional Caddy HTTPS, Pterodactyl egg, CI workflow, and backup tooling

## Call architecture

```mermaid
flowchart TD
    PSTN[Customer, Google, or staff phone] --> Twilio[Twilio Elastic SIP Trunk]
    Twilio --> Asterisk[Asterisk PJSIP]
    Asterisk --> Gate[Opening-audio Call Gate]
    Gate -->|Direct or Google-forwarded customer| Inbound[Floodman inbound agent]
    Gate -->|Google automated business call| GoogleAgent[Restricted Google agent]
    Gate -->|Suspicious Google claim| Security[Security agent]
    Inbound --> Tools[Purpose-limited tools]
    GoogleAgent --> Tools
    Security --> Tools
    Tools --> Ledger[(Local SQLite ledger)]
    Tools --> Roomflow[Roomflow adapter]
    Roomflow --> Outbox[(Durable outbox)]
    Dashboard[Operations dashboard] --> Ledger
    Campaigns[Outbound campaign worker] --> Compliance[Deterministic compliance gate]
    Compliance --> AMI[Asterisk AMI]
    AMI --> Twilio
```

The model does not decide whether an outbound call is legal or eligible. The policy engine makes that decision before Asterisk dials. The model also cannot declare a customer verified or switch to another customer record after verification.

# Recommended Twilio deployment

## Prerequisites

You need:

- A Linux host with Docker Engine and Docker Compose
- A static, globally routable public IPv4 address with direct UDP access
- A DNS name for the dashboard, such as `voice.floodman.com`
- A Twilio account and an owned voice-capable number
- A Twilio API key for one-time provisioning
- A strong SIP username and password
- One operator-owned mobile number for controlled test calls
- Floodman’s human transfer numbers for reception, emergency, billing, and estimating

Do not deploy the SIP service behind an HTTP-only reverse proxy. SIP signaling and RTP media must reach the host directly.

## 1. Create the runtime environment

```bash
cp .env.twilio.example .env
chmod 600 .env
```

Replace every example value, especially:

```dotenv
VOICE_DOMAIN=voice.floodman.com
PUBLIC_BASE_URL=https://voice.floodman.com
TRUSTED_HOSTS=voice.floodman.com,localhost,127.0.0.1
PUBLIC_IP=<your real public IPv4>
TWILIO_TERMINATION_URI=<unique-name>.pstn.ashburn.twilio.com
TWILIO_SIP_USERNAME=<strong SIP username>
TWILIO_SIP_PASSWORD=<strong SIP password>
TWILIO_PHONE_NUMBER=+1XXXXXXXXXX
TWILIO_FROM_NUMBER=+1XXXXXXXXXX
OUTBOUND_CALLER_ID_NUMBER=+1XXXXXXXXXX
FLOODMAN_LIVE_NUMBER=+1XXXXXXXXXX
FLOODMAN_EMERGENCY_NUMBER=+1XXXXXXXXXX
FLOODMAN_BILLING_NUMBER=+1XXXXXXXXXX
FLOODMAN_ESTIMATING_NUMBER=+1XXXXXXXXXX
TEST_CALL_ALLOWLIST=+1<operator-mobile>
```

The documentation address `203.0.113.10` is intentionally rejected by strict preflight. Replace it with the real public address.

## 2. Create the one-time provisioning environment

```bash
cp .env.twilio-provisioning.example .env.twilio-provisioning
chmod 600 .env.twilio-provisioning
```

Fill in:

```dotenv
TWILIO_ACCOUNT_SID=AC...
TWILIO_API_KEY=SK...
TWILIO_API_KEY_SECRET=...
TWILIO_TRUNK_DOMAIN=<unique-name>.pstn.twilio.com
TWILIO_ORIGINATION_SIP_URI=sip:<public-ip>:5060;edge=ashburn
```

Prefer a restricted Twilio API key. Do not put the API key, API secret, Account Auth Token, or provisioning file into the long-running container. The running service needs only the SIP credentials from `.env`.

## 3. Run validation before changing Twilio

```bash
make validate
make test
python3 scripts/preflight.py \
  --env-file .env \
  --env-file .env.twilio-provisioning \
  --require-provisioning \
  --strict
```

## 4. Provision the trunk safely

```bash
make twilio-config
make twilio-plan
make twilio-apply
make twilio-verify
```

`plan` is read-only. Review it before `apply`.

If the number already uses a webhook, TwiML application, or another trunk, the script refuses to move it. Inspect the existing routing first. Only set this temporarily when the route change is intentional:

```dotenv
TWILIO_ALLOW_PHONE_ROUTING_CHANGE=true
```

Return it to `false` after the change.

## 5. Start with automatic HTTPS

```bash
docker compose \
  -f docker-compose.yml \
  -f docker-compose.caddy.yml \
  up -d --build
```

The dashboard binds to loopback in the base Compose file. Caddy publishes ports 80 and 443 and blocks `/internal/*` before proxying to the application.

Retrieve the generated admin token without printing every runtime secret:

```bash
docker compose exec floodman-voice \
  sh -lc "grep '^export ADMIN_TOKEN=' /home/container/data/runtime.env"
```

Open `https://voice.floodman.com` and enter that token.

## 6. Confirm runtime readiness

```bash
curl -fsS https://voice.floodman.com/livez
curl -fsS https://voice.floodman.com/readyz

docker compose exec floodman-voice \
  python /opt/floodman/scripts/preflight.py --strict
```

The dashboard’s diagnostics page should show:

- SQLite ready
- Call gate listening
- Asterisk ARI authenticated
- AVA Stasis application registered
- AMI authenticated when test calls are enabled
- Twilio termination hostname resolving
- No critical configuration failures

## 7. Test the carrier before testing the AI

Use this order:

1. Enable Twilio’s free `Play` termination test extensions or call Twilio’s test numbers from Asterisk.
2. Use Twilio Console’s trunk origination test to call the associated DID.
3. Enable one allowlisted operator echo call.
4. Place a direct inbound cellular call to the temporary DID.
5. Test reception, emergency, billing, and estimating transfers.
6. Test AVA on a direct call.
7. Test Google forwarding only after direct calls are stable.

For the controlled echo call:

```dotenv
AMI_ENABLED=true
TEST_CALLS_ENABLED=true
TEST_CALL_ALLOWLIST=+1<operator-mobile>
```

Restart the service, place the test call from the dashboard, answer, and confirm that your voice is returned by Asterisk. Then disable `TEST_CALLS_ENABLED` again.

The echo test proves outbound SIP signaling and two-way RTP without involving the speech model. It is the fastest way to separate a carrier or firewall problem from an AI problem.

See [Twilio setup and call testing](docs/TWILIO_SETUP.md).

# Secure SIP upgrade

After UDP/RTP calls pass, move to TLS and SRTP:

1. Place a valid certificate and key in `secrets/sip/`.
2. Copy `.env.twilio-secure.example` to `.env` and fill all real values.
3. Set the Twilio origination URI to use `transport=tls`.
4. Re-run `preflight`, `plan`, `apply`, and `verify`.
5. Start with the secure overlay:

```bash
docker compose \
  -f docker-compose.yml \
  -f docker-compose.caddy.yml \
  -f docker-compose.twilio-secure.yml \
  up -d --build
```

6. Repeat every carrier and transfer test.

# AVA voice provider

The default profile uses AVA’s local-hybrid pipeline. The image includes the call-gate Whisper model, but a complete conversational pipeline still needs either:

- AVA local models installed on sufficient CPU/GPU hardware, or
- configured cloud STT, model, and TTS provider credentials.

For a small local proof test:

```dotenv
AUTO_INSTALL_LOCAL_MODELS=true
LOCAL_MODEL_TIER=LIGHT
```

Restart once and monitor model installation. After the models are ready, set `AUTO_INSTALL_LOCAL_MODELS=false` so every restart does not attempt installation again.

Cloud provider configuration belongs in the persistent AVA config under:

```text
/home/container/data/config/ava/ai-agent.local.yaml
```

Do not move the main business number until the diagnostics show the AVA Stasis application registered and a direct test call completes cleanly.

# Google call handling

The call gate listens before AVA greets the caller. It can:

1. Detect Google forwarding and recording announcements.
2. Stay quiet until the real customer is connected.
3. Remove the announcement from the customer’s opening transcript.
4. Preserve the customer’s first useful sentence.
5. Route automated Google business-information calls to a restricted agent.
6. Route password, payment, verification-code, remote-access, or listing-pressure language to a security agent.
7. Fail open to ordinary customer service when classification is uncertain.
8. Greet a genuinely silent direct caller after the configured short timeout.

See [Google call gate](docs/GOOGLE_CALL_GATE.md).

# Roomflow

Roomflow remains the preferred business system of record. The local ledger writes first, then attempts the mapped Roomflow operation with a stable idempotency key. Failed mutations enter a retry outbox rather than disappearing.

Configure the exact private Roomflow paths in:

```text
/home/container/data/config/floodman.yaml
```

Use `config/examples/roomflow-endpoints.example.yaml` as the mapping template. Keep `ROOMFLOW_ENABLED=false` until staging calls create the expected customers, properties, leads, appointments, callbacks, and call outcomes.

See [Roomflow integration](docs/ROOMFLOW.md).

# Outbound callbacks, billing, and win-back

The system supports requested callbacks, missed-call recovery, billing reminders, estimate follow-up, canceled-inspection recovery, maintenance reminders, and customer win-back campaigns.

Do not enable campaign dialing until Floodman has reviewed consent language, calling windows, recording disclosures, DNC screening, reassigned-number screening, frequency caps, voicemail wording, payment handling, and opt-out behavior with counsel.

```dotenv
AMI_ENABLED=true
OUTBOUND_ENABLED=true
```

Outbound calls are subject to the deterministic eligibility engine immediately before dialing. Billing calls require server-side customer verification before private invoice details are available. Full card or bank credentials must never enter the general AI, recording, or transcript path.

See [Outbound and compliance](docs/OUTBOUND_COMPLIANCE.md).

# Security defaults

- Runtime secrets are generated into `DATA_DIR/runtime.env` with mode `0600`.
- Bootstrap secrets are not printed unless `PRINT_BOOTSTRAP_SECRETS=true` is deliberately set.
- Twilio REST API credentials remain outside the running container.
- The container runs as UID 988 with all Linux capabilities dropped in Compose.
- ARI and AMI bind to `127.0.0.1`.
- The dashboard binds to loopback by default.
- API documentation is disabled by default.
- Caddy blocks `/internal/*` from public access.
- Trusted hosts and trusted proxy sources are restricted.
- Security headers and HSTS are enabled when requests are received as HTTPS.
- Uploaded files are signed, size-limited, type-checked, renamed, and stored with restrictive permissions.
- Twilio symmetric RTP is disabled by default. Enable it only as a diagnosed NAT workaround.

See [Security policy](SECURITY.md) and [Production checklist](docs/PRODUCTION_CHECKLIST.md).

# Backups

Create a live-safe SQLite backup:

```bash
docker compose exec floodman-voice \
  python /opt/floodman/scripts/backup.py
```

The backup tool uses SQLite’s online backup API, runs integrity checks, builds a manifest, verifies every SHA-256 digest, and writes a mode `0600` archive. Media and runtime secrets are excluded by default.

Copy the archive off the voice host. Store `.env` and `.env.twilio-provisioning` separately in encrypted secret storage.

See [Backup and recovery](docs/BACKUP_AND_RECOVERY.md).

# Pterodactyl

Import:

```text
egg-floodman-operations-voice-aio-v1.1.1.json (or pterodactyl/egg-floodman-operations-voice-aio.json)
```

Pterodactyl must provide direct public SIP and RTP allocations. Do not place Twilio API credentials in egg variables. Provision the Twilio trunk from a trusted workstation or through Twilio Console, then store only runtime SIP credentials in the server variables.

See [Pterodactyl deployment](docs/PTERODACTYL.md).

# Development and validation

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e '.[test]'
make validate
make test
```

Strict configuration preflight:

```bash
python3 scripts/preflight.py \
  --env-file .env \
  --env-file .env.twilio-provisioning \
  --require-provisioning \
  --strict
```

# Admin API

Admin routes accept:

```http
Authorization: Bearer <ADMIN_TOKEN>
```

or:

```http
X-Admin-Token: <ADMIN_TOKEN>
```

Interactive API documentation is disabled in production. Temporarily set `ENABLE_API_DOCS=true` only on a restricted management network. Internal AVA and AGI routes use `X-Internal-Token` and must never be exposed through the public reverse proxy.

# Persistent data

Mutable state is stored under `DATA_DIR`, defaulting to `/home/container/data`:

```text
data/
├── asterisk/
├── ava/
├── backups/
├── cache/
├── config/
├── gate-audio/
├── logs/
├── model-cache/
├── models/
├── recordings/
├── twilio/
├── uploads/
├── floodman-voice.sqlite3
└── runtime.env
```

# Documentation

- [Twilio setup and call testing](docs/TWILIO_SETUP.md)
- [Production checklist](docs/PRODUCTION_CHECKLIST.md)
- [Backup and recovery](docs/BACKUP_AND_RECOVERY.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Pterodactyl deployment](docs/PTERODACTYL.md)
- [Asterisk and FreePBX](docs/FREEPBX_ASTERISK.md)
- [Roomflow integration](docs/ROOMFLOW.md)
- [Google call gate](docs/GOOGLE_CALL_GATE.md)
- [Outbound and compliance](docs/OUTBOUND_COMPLIANCE.md)
- [Testing and rollout](docs/TESTING_AND_ROLLOUT.md)
- [Security policy](SECURITY.md)
- [Third-party notices](THIRD_PARTY_NOTICES.md)

# License

Floodman Operations Voice AIO is MIT licensed. AVA and all downloaded dependencies retain their own licenses.
